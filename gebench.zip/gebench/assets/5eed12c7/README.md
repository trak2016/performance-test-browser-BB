yii2-strength-meter
===================

This plugin is fork of [Kartiks strength-meter plugin](https://github.com/kartik-v/strength-meter)

It is optimized to be a core part of yii2 application templates created by Nenad Zivkovic.
